<?php

use App\Http\Controllers\ChannelController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\HookController;
use App\Http\Controllers\MessageController;
use Illuminate\Support\Facades\Route;


Route::get('/webhook/telegram',[HookController::class , 'getMessage']);

Route::group(['prefix' => 'api'], function () {
    Route::post('/login', [Controller::class,'login']);
    Route::post('/checkCode',[Controller::class,'checkCode']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/channels', [ChannelController::class, 'getMy']);
        Route::post('/addChannel', [ChannelController::class, 'add']);
        Route::get('/channel/{id}/messages', [ChannelController::class, 'getMessages']);
        Route::post('/channel/{id}/delete/{message}', [ChannelController::class, 'delete']);
        Route::post('/channel/{id}/send', [MessageController::class, 'send']);
        Route::post('/message/{message}/channel/{id}', [MessageController::class, 'sendMessage']);
    });
});
