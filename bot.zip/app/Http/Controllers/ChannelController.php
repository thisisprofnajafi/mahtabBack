<?php

namespace App\Http\Controllers;

use App\Models\Channel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Telegram\Bot\Laravel\Facades\Telegram;

class ChannelController extends Controller
{
    public function add(Request $request)
    {
        $request->validate([
            'id' => 'required'
        ]);
        $user = Auth::user();

        $ch = $user->channels()->where('channel_id', $request->id)->first();

        if (!$ch) {
            $channel = Telegram::getChat(['chat_id' => '@' . $request->id]);
            if ($channel) {
                $channelName = $channel['title'];
                $channelId = $channel['id'];
                $profilePhoto = $channel->getPhoto();
                $ch = new Channel();
                $ch->title = $channelName;
                $ch->channel_id = $request->id;
                $ch->chat_id = $channelId;
                $members = Telegram::getChatMemberCount(['chat_id' => '@' . $request->id]);
                $ch->members_count = $members;
                if ($profilePhoto) {
                    $profilePhotoFile = Telegram::getFile(['file_id' => $profilePhoto['big_file_id']]);
                    $profilePhotoUrl = 'https://api.telegram.org/file/bot' . env('TELEGRAM_BOT_TOKEN') . '/' . $profilePhotoFile->getFilePath();
                    $localFilePath = public_path('media/channels/' . $request->id . '.jpg');
                    file_put_contents($localFilePath, file_get_contents($profilePhotoUrl));
                    $ch->profile_path = $localFilePath;
                }
                $user->channels()->save($ch);
                return response()->json([
                    'message' => "channel added",
                    "status" => true
                ], 200);
            }
            return response()->json([
                'message' => "channel not found",
                "status" => true
            ], 404);
        }
        return response()->json([
            'message' => "channel already exists",
            "status" => true
        ], 200);

    }

    public function getMy()
    {
        return Auth::user()->channels;
    }

    public function getMessages($id, Request $request)
    {
        $skip = $request->skip;
        $user = Auth::user();
        $channel = $user->channels()->where('id', $id)->first();
        $count = $channel->messages->count();

        if ($skip) {
            $messages = $channel->messages()->orderBy('created_at', 'desc')->skip($skip)->take(20)->get();
        }
        $messages = $channel->messages()->orderBy('created_at', 'desc')->skip(0)->take(20)->get();

        return response()->json([

            'messages' => $messages,
            "count" => $count

        ]);
    }

    public function delete($id, $message)
    {
        $channel = Auth::user()->channels->where("id", $id)->first();
        if ($channel) {
            $message = $channel->messages->where("message_id", $message)->first();
            if ($message) {
                try {
                    Telegram::deleteMessage([
                        'chat_id' => $channel->chat_id,
                        'message_id' => $message->message_id,
                    ]);
                    return response()->json([
                        "status" => true,
                        "message" => "Deleted"
                    ]);
                }catch (\Exception $e){
                    return response()->json([
                        "status" => false,
                        "message" => $e->getMessage()
                    ]);
                }

            } else {
                return response()->json([
                    "status" => false,
                    "message" => "Message Not Found"
                ]);
            }
        }
        return response()->json([
            "status" => false,
            "message" => "Channel Not Found"
        ]);
    }
}
