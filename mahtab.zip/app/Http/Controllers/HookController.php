<?php

namespace App\Http\Controllers;

use App\Models\Channel;
use Illuminate\Http\Request;
use Telegram\Bot\Laravel\Facades\Telegram;

class HookController extends Controller
{
    public function getMessage()
    {
        $updates = Telegram::getUpdates();
        foreach ($updates as $update) {
            if ($update->channel_post) {
                echo "<pre>" . json_encode($update, JSON_PRETTY_PRINT) . "<pre>";
                if ($update->channel_post->sender_chat->type == "channel") {
                    $channel = Channel::query()->where('channel_id', $update->channel_post->sender_chat->username)->first();
                    if ($channel) {
                        if ($update->channel_post->text) {
                            $channel->saveText($update->channel_post);
                        }
                        if ($update->channel_post->photo) {
                            $channel->savePhoto($update->channel_post);
                        }
                        if ($update->channel_post->document) {

                            if ($update->channel_post->animation)
                                $channel->saveGif($update->channel_post);
                            else
                                $channel->saveDoc($update->channel_post);
                        }

                        if ($update->channel_post->sticker) {
                            $channel->saveSticker($update->channel_post);
                        }

                        if ($update->channel_post->video) {
                            $channel->saveVideo($update->channel_post);
                        }

                        if ($update->channel_post->audio) {
                            $channel->saveAudio($update->channel_post);
                        }

                        if ($update->channel_post->voice) {
                            $channel->saveVoice($update->channel_post);
                        }
                    }
                }
                echo '<br><br>';
            }
        }
        dd($updates);
    }

}
